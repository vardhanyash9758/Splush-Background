import { NextResponse } from "next/server"

export async function POST(req: Request) {
  try {
    const { image } = await req.json()

    // Convert base64 to binary
    const base64Data = image.split(",")[1]
    const imageBuffer = Buffer.from(base64Data, "base64")

    const formData = new FormData()
    const blob = new Blob([imageBuffer], { type: "image/png" })
    formData.append("image_file", blob)

    const response = await fetch("https://api.remove.bg/v1.0/removebg", {
      method: "POST",
      headers: {
        "X-Api-Key": process.env.REMOVEBG_API_KEY!,
      },
      body: formData,
    })

    if (!response.ok) {
      throw new Error("Failed to remove background")
    }

    const buffer = await response.arrayBuffer()
    const base64 = Buffer.from(buffer).toString("base64")
    const processedImage = `data:image/png;base64,${base64}`

    return NextResponse.json({ processedImage })
  } catch (error) {
    console.error("Error:", error)
    return NextResponse.json({ error: "Failed to process image" }, { status: 500 })
  }
}

