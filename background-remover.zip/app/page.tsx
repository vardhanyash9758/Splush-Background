"use client"

import type React from "react"

import { useState } from "react"
import { Upload, Sparkles, ImageIcon, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export default function BackgroundRemover() {
  const [originalImage, setOriginalImage] = useState<string | null>(null)
  const [processedImage, setProcessedImage] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setOriginalImage(e.target?.result as string)
        setProcessedImage(null)
      }
      reader.readAsDataURL(file)
    }
  }

  const removeBackground = async () => {
    if (!originalImage) return

    setLoading(true)
    try {
      const response = await fetch("/api/remove-bg", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ image: originalImage }),
      })

      const data = await response.json()
      setProcessedImage(data.processedImage)
    } catch (error) {
      console.error("Error removing background:", error)
    }
    setLoading(false)
  }

  const handleDownload = () => {
    if (!processedImage) return

    // Create a temporary link element
    const link = document.createElement("a")
    link.href = processedImage
    link.download = "splush-background.png"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 to-teal-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">✨ Splush Background ✨</h1>
          <p className="text-gray-600">Transform your photos with a splash of magic! ✨</p>
        </div>

        <Card className="p-6 bg-white/80 backdrop-blur-sm shadow-xl rounded-2xl">
          <div className="space-y-6">
            <div className="flex justify-center">
              <div className="relative">
                <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" id="image-upload" />
                <label
                  htmlFor="image-upload"
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-rose-100 hover:bg-rose-200 transition-colors cursor-pointer text-rose-600"
                >
                  <Upload className="w-4 h-4" />
                  Upload your image
                </label>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {originalImage && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-600 flex items-center gap-1">
                    <ImageIcon className="w-4 h-4" /> Original Image
                  </p>
                  <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                    <img
                      src={originalImage || "/placeholder.svg"}
                      alt="Original"
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              )}

              {processedImage && (
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-600 flex items-center gap-1">
                    <Sparkles className="w-4 h-4" /> Processed Image
                  </p>
                  <div className="aspect-square rounded-lg overflow-hidden bg-gray-100">
                    <img
                      src={processedImage || "/placeholder.svg"}
                      alt="Processed"
                      className="w-full h-full object-contain"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-center gap-4">
              {originalImage && !processedImage && (
                <Button
                  onClick={removeBackground}
                  disabled={loading}
                  className="bg-teal-500 hover:bg-teal-600 text-white rounded-full"
                >
                  {loading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/50 border-t-white rounded-full animate-spin" />
                      Processing...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      Remove Background
                    </div>
                  )}
                </Button>
              )}

              {processedImage && (
                <Button
                  onClick={handleDownload}
                  className="bg-purple-500 hover:bg-purple-600 text-white rounded-full group"
                >
                  <div className="flex items-center gap-2">
                    <Download className="w-4 h-4 group-hover:animate-bounce" />
                    Download Image
                  </div>
                </Button>
              )}
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

